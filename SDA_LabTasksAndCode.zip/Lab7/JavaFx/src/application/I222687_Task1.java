package application;
	
import java.io.FileInputStream;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;


public class I222687_Task1 extends Application {

	@Override
	public void start(Stage primaryStage) {
		try {
			/*BorderPane root = new BorderPane();
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();*/
			
			GridPane gridRoot = new GridPane();
			gridRoot.setPadding(new Insets(20,20,20,20)); // Really very helpful for setting padding on all four sides by value 20.
			gridRoot.setVgap(10);
			
			Label nameLabel = new Label("Full Name: ");
			TextField nameText = new TextField();
			gridRoot.add(nameLabel, 0, 0);
			gridRoot.add(nameText, 1, 0);
			
			Label dobLabel = new Label("Date of Birth: ");
	        DatePicker dobPicker = new DatePicker();
	        gridRoot.add(dobLabel, 0, 1);
	        gridRoot.add(dobPicker, 1, 1);
	        
	        Label genderLabel = new Label("Select Gender: ");
	        ToggleGroup toggle = new ToggleGroup();
	        RadioButton bt1 = new RadioButton("Male");
	        RadioButton bt2 = new RadioButton("Female");
	        RadioButton bt3 = new RadioButton("Other");
	        bt1.setToggleGroup(toggle);
	        bt2.setToggleGroup(toggle);
	        bt3.setToggleGroup(toggle);
	        gridRoot.add(genderLabel, 0, 2);
//	        gridRoot.add(bt1, 1, 2);
//	        gridRoot.add(bt2, 2, 2);
//	        gridRoot.add(bt3, 3, 2);
	        HBox genderBox = new HBox(10, bt1, bt2, bt3);
	        gridRoot.add(genderBox, 1, 2);
	        
	        Label emailLabel = new Label("Email Address: ");
	        TextField emailText = new TextField();
	        gridRoot.add(emailLabel, 0, 3);
	        gridRoot.add(emailText, 1, 3);
			
	        Label contactNumberLabel = new Label("Contact Number: ");
	        TextField contactNumber = new TextField();
	        gridRoot.add(contactNumberLabel, 0, 4);
	        gridRoot.add(contactNumber, 1, 4);
	        
	        Label addressLabel = new Label("Address: ");
	        TextField addressText = new TextField();
	        gridRoot.add(addressLabel, 0, 5);
	        gridRoot.add(addressText, 1, 5);
	        
	        Label coursesLabel = new Label("Courses: ");
	        ListView courses = new ListView();
	        courses.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
	        courses.getItems().add("Business Process Engineering");
	        courses.getItems().add("Software Design and Architecture");
	        courses.getItems().add("Software Design and Architecture - LAB");
	        courses.getItems().add("Probability and Statistics");
	        courses.getItems().add("Database Systems");
	        courses.getItems().add("Database Systems - LAB");
	        courses.getItems().add("Marketing Management");
	        gridRoot.add(coursesLabel, 0, 6);
	        gridRoot.add(courses, 1, 6);

//	        Button submitButton = new Button("Submit");
//	        submitButton.setOnAction(event -> {
//	        	if (nameText.getText().isEmpty()) nameText.setPromptText("Full Name required!");
//	            if (dobPicker.getValue() == null) dobPicker.setPromptText("Date of Birth required!");
//	            if (emailText.getText().isEmpty()) emailText.setPromptText("Email required!");
//	            if (contactNumber.getText().isEmpty()) contactNumber.setPromptText("Contact Number required!");
//	            if (addressText.getText().isEmpty()) addressText.setPromptText("Address required!");
//	            if (courses.getSelectionModel().getSelectedItems().isEmpty()) 
////	            if (!nameText.getText().isEmpty() && dobPicker.getValue() != null && !emailText.getText().isEmpty() && !contactNumber.getText().isEmpty() && !addressText.getText().isEmpty()) {
////	            	Scene showSuccessMessage = new Scene(label, 20, 20);
////	            	showSuccessMessage.
////	            	
////	            }
//	        });
	        
	        Button submitButton = new Button("Submit");
	        submitButton.setOnAction(e -> {
	            if (nameText.getText().isEmpty() ||
	                    dobPicker.getValue() == null ||
	                    emailText.getText().isEmpty() ||
	                    contactNumber.getText().isEmpty() ||
	                    addressText.getText().isEmpty() ||
	                    toggle.getSelectedToggle()  == null ||
	                    courses.getSelectionModel().getSelectedItems().isEmpty()) {
	            	String errorString = "";
	                Alert alert = new Alert(Alert.AlertType.ERROR);
	                alert.setTitle("Error");
	                alert.setHeaderText(null);
	                if (nameText.getText().isEmpty()) {
	                	errorString += "Full Name required!\n";
	                }
	                if (dobPicker.getValue() == null) {
	                	errorString += "Date of Birth required!\n";
	                }
	                if (emailText.getText().isEmpty()) {
	                	errorString += "Email required!\n";
	                }
	                if (contactNumber.getText().isEmpty()) {
	                	errorString += "Contact Number required!\n";
	                }
	                if (addressText.getText().isEmpty()) {
	                	errorString += "Address required!\n";
	                }
	                if (toggle.getSelectedToggle() == null) {
	                	errorString += "Gender required!\n";
	                }
	                if (courses.getSelectionModel().getSelectedItems().isEmpty()) {
	                	errorString += "Course required!\n";
	                }
	                alert.setContentText(errorString);
	                alert.showAndWait();
	            } else {
	                String coursesStr = String.join(", ", courses.getSelectionModel().getSelectedItems());
	                Alert alert = new Alert(Alert.AlertType.INFORMATION);
	                alert.setTitle("Confirmation");
	                alert.setHeaderText(null);
	                alert.setContentText("Registration successful!\n\n" +
	                        "Name: " + nameText.getText() + "\n" +
	                        "Date of Birth: " + dobPicker.getValue() + "\n" +
	                        "Gender: " + ((RadioButton) toggle.getSelectedToggle()).getText() + "\n" +
	                        "Email: " + emailText.getText() + "\n" +
	                        "Contact Number: " + contactNumber.getText() + "\n" +
	                        "Address: " + addressText.getText() + "\n" +
	                        "Courses: " + coursesStr);
	                alert.showAndWait();
	            }
	        });
	        gridRoot.add(submitButton, 1, 7);
			      
	        Menu menu = new Menu("Form");
	        MenuItem clearMenuItem = new MenuItem("Clear");
	        clearMenuItem.setOnAction(event -> {
	        	nameText.clear();
	            dobPicker.setValue(null);
	            toggle.selectToggle(null);
	            emailText.clear();
	            contactNumber.clear();
	            addressText.clear();
	            courses.getSelectionModel().clearSelection();
	        });
	        MenuItem exitMenuItem = new MenuItem("Exit");
	        exitMenuItem.setOnAction(e -> primaryStage.close());
	        menu.getItems().addAll(clearMenuItem, exitMenuItem);
	        MenuBar menuBar = new MenuBar();
	        menuBar.getMenus().add(menu);

			VBox vbox = new VBox();
		    vbox.getChildren().addAll(menuBar, gridRoot);
		    
		    Scene scene = new Scene(vbox, 400, 600);
			primaryStage.setTitle("Registration Form");
			primaryStage.setScene(scene);
		    primaryStage.show();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
