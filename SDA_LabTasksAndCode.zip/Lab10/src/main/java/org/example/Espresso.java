package org.example;

public class Espresso extends Coffee {
    public Espresso() {
        setType("Espresso");
        setSize("Regular");
        setPrice(2.0);
    }
}