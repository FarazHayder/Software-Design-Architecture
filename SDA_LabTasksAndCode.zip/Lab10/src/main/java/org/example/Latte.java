package org.example;

public class Latte extends Coffee {
    public Latte() {
        setType("Latte");
        setSize("Large");
        setPrice(3.5);
    }
}