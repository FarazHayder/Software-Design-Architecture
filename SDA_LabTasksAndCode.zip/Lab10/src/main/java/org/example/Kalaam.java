package org.example;

public class Kalaam {
    private String title;
    private String artist;
    private int duration;

    public Kalaam(String title, String artist, int duration) {
        this.title = title;
        this.artist = artist;
        this.duration = duration;
    }

    @Override
    public String toString() {
        return title + " by " + artist + " of " + duration + " minutes in duration.";
    }
}
