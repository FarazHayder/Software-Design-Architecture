package org.example;

import org.springframework.beans.factory.annotation.Autowired;

public class CoffeeShop {
    @Autowired
    private Coffee coffee;

    public void serveCoffee() {
        System.out.println("The coffee being served is a " + coffee);
    }

    public void setCoffee(Coffee coffee) {
        this.coffee = coffee;
    }
}