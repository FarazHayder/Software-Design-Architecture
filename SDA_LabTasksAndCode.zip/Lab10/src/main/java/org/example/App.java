package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class App 
{
    @Autowired
    private MP3Player mp3Player = new MP3Player();

    public void load(Kalaam hamd, Kalaam naat){
        mp3Player.setHamd(hamd);
        mp3Player.setNaat(naat);
    }
    public void play() {
        mp3Player.playHamd();
        mp3Player.playNaat();
    }

    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        CoffeeShop coffeeShop = (CoffeeShop) context.getBean("coffeeShop");
        coffeeShop.serveCoffee();
        ApplicationContext context1 = new ClassPathXmlApplicationContext("spring2.xml");
        App app = (App) context1.getBean("app");
        Hamd hamd = new Hamd("SubhanAllah", "Ahmed Bukhatir", 5);
        Naat naat = new Naat("Ya Rasulallah", "Sami Yusuf", 4);
        app.load(hamd,naat);
        app.play();
    }
}