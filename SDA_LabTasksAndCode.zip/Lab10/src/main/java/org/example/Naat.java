package org.example;

public class Naat extends Kalaam {
    public Naat(String title, String artist, int duration) {
        super(title, artist, duration);
    }
}
