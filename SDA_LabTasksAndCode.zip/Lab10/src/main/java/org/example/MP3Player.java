package org.example;

public class MP3Player {
    private Kalaam hamd;
    private Kalaam naat;

    public void playHamd() {
        System.out.println("The Hamd being played is " + hamd);
    }

    public void playNaat() {
        System.out.println("The Naat being played is " + naat);
    }

    public void setHamd(Kalaam hamd) {
        this.hamd = hamd;
    }

    public void setNaat(Kalaam naat) {
        this.naat = naat;
    }
}

