package org.example;

public class Hamd extends Kalaam {
    public Hamd(String title, String artist, int duration) {
        super(title, artist, duration);
    }
}
