package org.example.lab9;

import java.io.*;
import java.util.ArrayList;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "BookServlet", value = "/book-servlet")
public class BookServlet extends HttpServlet {
    private ArrayList<Book> books;
    public BookServlet() {
        // Here I'm initializing the list of books
        books = new ArrayList<>();
        books.add(new Book("Forty Rules of Love", "Elif Shafak", "Historical Fiction", 750));
        books.add(new Book("The Alchemist", "Paulo Coelho", "Fantasy Fiction", 1000));
        books.add(new Book("Great Expectations", "Charles Dickens", "Gothic Fiction", 890));
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>" +
                        "<head>" +
                            "<title>Books List</title>" +
                        "</head>" +
                        "<body>" +
                            "<h1>Books List</h1>" +
                            "<table border=\"1\">" +
                            "<tr>" +
                                "<th>Title</th>" +
                                "<th>Author</th>" +
                                "<th>Genre</th>" +
                                "<th>Price</th>" +
                            "</tr>");
        for (Book book : books) {
            out.println("<tr>");
            out.println("<td>" + book.getTitle() + "</td>");
            out.println("<td>" + book.getAuthor() + "</td>");
            out.println("<td>" + book.getGenre() + "</td>");
            out.println("<td>" + book.getPrice() + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");
        out.println("</body></html>");
    }

    public void destroy() {
    }
}

class Book {
    private String title;
    private String author;
    private String genre;
    private double price;

    public Book(String title, String author, String genre, double price) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public double getPrice() {
        return price;
    }
}