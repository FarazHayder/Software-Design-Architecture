import java.net.*;
import java.io.*;

class I222687_Q1_File1 {
    public static void main(String args[]) throws Exception {
        ServerSocket ss = new ServerSocket(3333);
        Socket s = ss.accept(); // Accepting connection from client
        DataInputStream din = new DataInputStream(s.getInputStream()); // Simply input but from client i.e. another
                                                                       // console (using ports)
        DataOutputStream dout = new DataOutputStream(s.getOutputStream()); // Simply output but to client i.e. another
                                                                           // terminal (using ports)

        String str = "", str2 = "";
        while (!str.equals("stop")) {
            str = din.readUTF(); // Receiving from client
            if (!str.equals("stop")) {
            	System.out.println("client says: " + str); // Writing client's string on console
            	// Counting number of vowels
            	int vowels = 0;
            	for (int i = 0; i < str.length(); i++) {
            		char ch = str.charAt(i);
            		if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
            				ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
            			vowels++;
            		}
            	}
            	if (vowels > 1) {
            		str2 = "There are " + vowels + " vowels in the string";            	
            	}
            	else if (vowels == 1){
            		str2 = "There is " + vowels + " vowel in the string";
            	}
            	else {
            		str2 = "There are no vowels in the string";	
            	}
            	dout.writeUTF(str2); // Returning string to client
            	dout.flush(); // Flushing for buffer in output stream
            }
        }
        din.close();
        s.close();
        ss.close();
    }
}