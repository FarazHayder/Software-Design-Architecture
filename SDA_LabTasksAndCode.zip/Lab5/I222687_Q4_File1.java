//Server/Receiver
import java.net.*;
import java.time.LocalTime;
public class I222687_Q4_File1 {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket(3000); //Creating a datagram socket that listens on port 3000 for incoming packets
        byte[] buf = new byte[1024]; //Creating a bytes array
        DatagramPacket dp = new DatagramPacket(buf, 1024); //Making this variable to store the incoming datapacket in bytes
        ds.receive(dp);
        String str = new String(dp.getData(), 0, dp.getLength());
        if (str.equals("Display Time")) //Checking if the request if for displaying time
        {        	
        	LocalTime currentServerTime = LocalTime.now();
            System.out.println(currentServerTime);
        }
        else {        	
        	System.out.println("Invalid Request!");
        }
        ds.close();
    }
}