import java.net.*;
import java.io.*;

class I222687_Q1_File2 {
    public static void main(String args[]) throws Exception {
        Socket s = new Socket("localhost", 3333);
        DataInputStream din = new DataInputStream(s.getInputStream()); // Simply input but from server i.e. another
        // console (using ports)
        DataOutputStream dout = new DataOutputStream(s.getOutputStream()); // Simply output but to server i.e. another
        // console (using ports)
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // Simply input from the console.
                                                                                  // (It's called buffered reader
                                                                                  // because it reads
                                                                                  // character-by-character and stores
                                                                                  // it in the buffer and when the user
                                                                                  // presses 'enter' then the input
                                                                                  // stream is eventually accessed,
                                                                                  // which means using buffer reader
                                                                                  // input stream is only accessed once.

        String str = "", str2 = "";
        while (!str.equals("stop")) {
        	str = br.readLine(); // Reading line from console
        	dout.writeUTF(str); // Sending the string to server side
        	dout.flush(); // Flushing the output stream for buffer
        	if (!str.equals("stop")) {        		
        		str2 = din.readUTF(); // Receiving from server
        		System.out.println("Server says: " + str2);
        	}
        }
        dout.close();
        s.close();
    }
}