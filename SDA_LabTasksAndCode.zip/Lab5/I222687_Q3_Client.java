import java.io.*;
import java.net.*;

public class I222687_Q3_Client {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName("localhost");

            File file = new File("data.txt");
            byte[] buf = new byte[1024];

            FileInputStream fin = new FileInputStream(file);
            fin.read(buf);
            fin.close();

            DatagramPacket dp = new DatagramPacket(buf, buf.length, serverAddress, 3333);
            ds.send(dp);

            System.out.println("File has been sent successfully!");

            ds.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}