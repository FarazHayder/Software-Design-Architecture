import java.io.*;
import java.net.*;

public class I222687_Q3_Server {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket(3333);
            byte[] buf = new byte[1024];
            DatagramPacket dp = new DatagramPacket(buf, buf.length);
            ds.receive(dp);

            File file = new File("data1.txt");

            String path = "data1.txt";
            FileOutputStream fout = new FileOutputStream(path);
            fout.write(dp.getData(), 0, dp.getLength());
            fout.close();

            ds.close();

            System.out.println("File has been saved successfully!");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}