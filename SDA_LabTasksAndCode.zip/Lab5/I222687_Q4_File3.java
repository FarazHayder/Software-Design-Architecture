//Client/Sender
import java.net.*;
public class I222687_Q4_File3 {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket();
        String str = "Display Time";
        InetAddress ip = InetAddress.getByName("127.0.0.1"); //IP Address of local host
        DatagramPacket dp = new DatagramPacket(str.getBytes(), str.length(), ip, 3000); //Making a packet containing the message(String) as bytes, the length of the message, the destination IP address (ip), and the destination port (3000).
        ds.send(dp); // Sending packet
        ds.close();
    }
}