import java.util.*;
import java.util.Scanner;

class Employee{
	String name;
	double salary;
	
	public Employee() {
		name = "";
		salary = 0;
	}
	public Employee(String name, int salary) {
		this.name = name;
		this.salary = salary;
	}
	@Override
    public String toString() {
        return "Employee{" + "name=" + name + ", salary=" + salary + '}';
    }
}

class EmployeeSalaryComparator implements Comparator<Employee> 
{
	@Override
	public int compare(Employee emp1, Employee emp2) {
		return Double.compare(emp1.salary, emp2.salary);
	}
}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in); //For input
		
		//Q1
		System.out.println("Q1:-");
		LinkedList<Integer> list = new LinkedList<>();
		list.addLast(1); //To add element at the last
		list.addLast(2); //To add element at the last
		list.addLast(3); //To add element at the last
		list.addFirst(4); //To add element at the first
		list.addFirst(5); //To add element at the first
		list.addFirst(6); //To add element at the first
		System.out.println("List = " + list);
		
		//Q2
		System.out.println("\nQ2:-");
		int startIndex = 0;
		do {
			System.out.print("Enter the starting index: ");
			startIndex = input.nextInt();
		}while(startIndex>=list.size() || startIndex<0);
		System.out.print("List from index " + startIndex+ " = ");
        System.out.print("[");
        for (int i = startIndex; i < list.size(); i++) {
            if (i!=list.size()-1) {            	
            	System.out.print(list.get(i) + ", ");
            }
            else {
            	System.out.print(list.get(i));	
            }
        }
        System.out.println("]");
        
      //Q3
      System.out.println("\nQ3:-");
      Stack<Integer> stack = new Stack<>();
      stack.push(1);
      stack.push(2);
      stack.push(3);
      stack.push(4);
      stack.push(5);
      System.out.println("Top element = " + stack.peek());
      System.out.println("Bottom element = " + stack.firstElement());
      
      //Q4
      System.out.println("\nQ4:-");
      Queue<Integer> queue = new LinkedList<>();
      queue.offer(1); // enqueue
      queue.offer(2); // enqueue
      queue.offer(3); // enqueue
      queue.offer(4); // enqueue
      queue.offer(5); // enqueue
      queue.offer(6); // enqueue
      queue.poll(); // dequeue
      queue.poll(); // dequeue
      queue.poll(); // dequeue
      //UNCOMMENT the following 3 lines to check the functionality of; if the queue is empty.
//      queue.poll(); // dequeue
//      queue.poll(); // dequeue
//      queue.poll(); // dequeue
      int rearElement = 0;
      for(int element: queue) {
    	  rearElement = element;
      }
      if(queue.isEmpty()) {
    	  System.out.println("Rear element = null");
      }
      else {    	  
    	  System.out.println("Rear element = " + rearElement);
      }
      System.out.println("Is queue empty? " + queue.isEmpty());
	  
      //Q5
      System.out.println("\nQ5:-");
      HashMap<Integer, String> hashMap = new HashMap<>();
      hashMap.put(1, "Ali");
      hashMap.put(2, "Hassan");
      hashMap.put(3, "Abdullah");
      hashMap.put(4, "Yahya");
      hashMap.put(5, "Haroon");
      System.out.println("Hash map => " + hashMap); 
      hashMap.remove(3);
      System.out.println("Hash map after removing using key=3 => " + hashMap);

      //Q6
      System.out.println("\nQ6:-");
      LinkedList<Employee> employees = new LinkedList<>();
      employees.add(new Employee("Ali", 10000));
      employees.add(new Employee("Hassan", 7000));
      employees.add(new Employee("Abdullah", 15000));
      employees.add(new Employee("Yahya", 9500));
      employees.add(new Employee("Haroon", 13000));
      System.out.println("Employees List before sorting => " + employees);
      EmployeeSalaryComparator comparator = new EmployeeSalaryComparator();
      Collections.sort(employees, comparator);
      System.out.println("Employees List after sorting => " + employees);
      
      
      input.close();
	}
}