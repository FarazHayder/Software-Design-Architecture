import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class I222687_Q1_L4_F {
	public static void main(String[] args) {

		File file = new File("data.txt"); // Creating a File object
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(file)); //Writer is like cout, of c++, or System.out.print() but for files.
			writer.write("My name is Faraz Hayder.");
			writer.newLine(); // For going to nextline (\n).
			writer.write("123456");
			writer.newLine();
			writer.write("12/34/56");
			writer.newLine();
			writer.write("Hello");
			writer.newLine();
			writer.write("World");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Now for reading from file:
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file)); //Reader is basically like cin of c++, but from file.
			// Reading lines from the file
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			// Closing the BufferedReader
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
