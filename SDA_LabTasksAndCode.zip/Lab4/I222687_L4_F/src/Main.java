import java.sql.*;

public class I222687_Q2_L4_F {
	public static void main(String[] args) {
		Connection myconn = null;
		Statement mystmt = null;
		ResultSet myRs = null;
		String user = "root";
		String pass = "Faraz";
		try {
			myconn = DriverManager.getConnection("jdbc:mysql:// localhost:3306/", user, pass);
			System.out.println("Connected Successfully");
			mystmt = myconn.createStatement();
			// mystmt.execute("create database mydb");
			mystmt.execute("use mydb");

			String createTableSQL = "CREATE TABLE IF NOT EXISTS Students (" +
					"id INT PRIMARY KEY," +
					"name VARCHAR(255)," +
					"age INT," +
					"grade VARCHAR(10)" +
					")";
			try (Statement statement = connection.createStatement()) {
				statement.executeUpdate(createTableSQL);
				System.out.println("Table created successfully.");
			}
			myRs = mystmt.executeQuery("Select * from emp");
			while (myRs.next()) {
				System.out.println(myRs.getInt("EMPNO"));
			}
			myconn.close();
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}
}