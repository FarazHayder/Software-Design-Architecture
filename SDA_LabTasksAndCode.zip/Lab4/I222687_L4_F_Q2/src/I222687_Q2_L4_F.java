import java.sql.*;

public class I222687_Q2_L4_F {
	static Connection myconn = null;
	static Statement mystmt = null;
	static ResultSet myRs = null;
	public static void main(String[] args) {
		String user = "root";
		String pass = "Faraz";
		try {
			myconn = DriverManager.getConnection("jdbc:mysql:// localhost:3306/", user, pass);
			System.out.println("Connected Successfully");
			mystmt = myconn.createStatement(); // To execute SQL queries and commands on the connected database
			 mystmt.execute("create database IF NOT EXISTS mydb"); //IF NOT EXISTS is very helpful, as it prevents from ungraceful termination of the program i.e. by throwing exceptions and terminating the program.
			mystmt.execute("use mydb");

            // Creating table
			//Simply pass the SQL query as string and using the executeUpdate command
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                                    "id INT PRIMARY KEY," +
                                    "name VARCHAR(255)," +
                                    "age INT(3)," +
                                    "grade VARCHAR(1)" +
                                    ")";
            boolean tableCreated = mystmt.executeUpdate(createTableSQL) == 0;
            if (tableCreated) {
                System.out.println("Table created successfully!");
            } else {
                System.out.println("Table already exists!");
            }
            
            // Inserting three entries of students
            String insertDataSQL1 = "INSERT INTO students VALUES (1, 'John', 20, 'A')";
            String insertDataSQL2 = "INSERT INTO students VALUES (2, 'Alice', 22, 'B')";
            String insertDataSQL3 = "INSERT INTO students VALUES (3, 'Bob', 21, 'C')";
            mystmt.executeUpdate(insertDataSQL1);
            mystmt.executeUpdate(insertDataSQL2);
            mystmt.executeUpdate(insertDataSQL3);
            System.out.println("Records inserted successfully!");
            
            displayRecords(); //Displaying records
			
            // Updating student records with specific ID
            // String updateSQL = "UPDATE Students SET grade = 'B' WHERE id = 1"; // For updating single student's entries we use this syntax
            String updateSQL = "UPDATE Students SET grade = 'B' WHERE id IN (1, 2, 3)";  // For updating multiple students' entries we use this syntax
            boolean rowsAffected = mystmt.executeUpdate(updateSQL) != 0;
            if (rowsAffected) {
                System.out.println("Grade(s) updated successfully!");
            } else {
                System.out.println("No record found!");
            }

            displayRecords(); //Displaying records
            
            // Deleting student records with specific ID
            // String deleteSQL = "DELETE FROM Students WHERE id = 1"; // For deleting single student's entries we use this syntax
            String deleteSQL = "DELETE FROM Students WHERE id IN (1, 2, 3)"; // For deleting multiple students' entries we use this syntax
            rowsAffected = mystmt.executeUpdate(deleteSQL) != 0;
            if (rowsAffected) {
                System.out.println("Record(s) deleted successfully!");
            } else {
                System.out.println("No record(s) found!");
            }

            displayRecords(); //Displaying records
            
			myconn.close();
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public static void displayRecords() {
		try {
			// SELECTing all the records FROM the Students table
			String selectSQL = "SELECT * FROM Students";
			myRs = mystmt.executeQuery(selectSQL);
	        // Iterating through the ResultSet and displaying each record
	        while (myRs.next()) {
	            int id = myRs.getInt("id");
	            String name = myRs.getString("name");
	            int age = myRs.getInt("age");
	            String grade = myRs.getString("grade");
	            System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age + ", Grade: " + grade);
	        }
		}
        catch (Exception exc) {
			exc.printStackTrace();
		}
	}
}