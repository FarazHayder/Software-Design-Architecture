
public class Student {

	int id;
	String name;
	int age;

	void setId(int id) {
		this.id = id;
	}
	int getId() {
		return id;
	}
	void setName(String name) {
		this.name = name;
	}
	String getName() {
		return name;
	}
	void setAge(int age) {
		this.age = age;
	}
	int getAge() {
		return age;
	}
}
