import java.util.ArrayList;

public class Enrollment {
	ArrayList<Course> courses = new ArrayList<Course>();
	
	void enroll(Student student, Course course) {
		if(courses.contains(course)) {
			if(!courses.get(courses.indexOf(course)).students.contains(student)) {
				courses.get(courses.indexOf(course)).students.add(student);
				System.out.println("Student enrolled successfully!");
			}
			else {
				System.out.println("Student already enrolled!");
			}
		}
		else {
			courses.add(course);
			if(!courses.get(courses.indexOf(course)).students.contains(student)) {
				courses.get(courses.indexOf(course)).students.add(student);
				System.out.println("Student enrolled successfully!");
			}
			else {
				System.out.println("Student already enrolled!");
			}
		}
	}
	void drop(Student student, Course course) {
		if(courses.contains(course)) {
			if(courses.get(courses.indexOf(course)).students.contains(student)) {				
				courses.get(courses.indexOf(course)).students.remove(student);
				System.out.println("Course dropped successfully!");
			}
			else {
				System.out.println("Student not enrolled!");
			}
		}
		else {
			System.out.println("Course Not Found!");
		}
	}
	void display() {
	    for (Course course : courses) {
	        System.out.println("\n" + course.getCourseName() + ": ");
	        for (Student student : course.getStudents()) {
	            System.out.println(student.getName());
	        }
	    }
	}
}
