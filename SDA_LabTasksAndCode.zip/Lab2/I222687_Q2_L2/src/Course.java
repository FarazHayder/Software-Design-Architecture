import java.util.LinkedList;

public class Course {

	String courseCode;
	String courseName;
	LinkedList<Student> students = new LinkedList<Student>();

	void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	String getCourseCode() {
		return courseCode;
	}
	void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	String getCourseName() {
		return courseName;
	}
	LinkedList<Student> getStudents() {
		return students;
	}
}
