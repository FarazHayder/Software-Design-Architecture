
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student();
		s1.setName("s1");
		s1.setAge(1);
		s1.setId(0);
		Student s2 = new Student();
		s2.setName("s2");
		s2.setAge(2);
		s2.setId(1);
		Student s3 = new Student();
		s3.setName("s3");
		s3.setAge(3);
		s3.setId(2);
		Student s4 = new Student();
		s4.setName("s4");
		s4.setAge(4);
		s4.setId(3);

		Course c1 = new Course();
		c1.setCourseName("c1");
		c1.setCourseCode("12");
		Course c2 = new Course();
		c2.setCourseName("c2");
		c2.setCourseCode("123");
		Course c3 = new Course();
		c3.setCourseName("c3");
		c3.setCourseCode("1234");
		Course c4 = new Course();
		c4.setCourseName("c4");
		c4.setCourseCode("12345");
		
		Enrollment Enroll = new Enrollment();
		Enroll.enroll(s1, c1);
		Enroll.enroll(s1, c2);
		Enroll.enroll(s1, c3);
		Enroll.enroll(s1, c4);
		Enroll.enroll(s2, c1);
		Enroll.enroll(s2, c2);
		Enroll.enroll(s4, c1);
		Enroll.enroll(s3, c1);
		Enroll.enroll(s3, c3);
		Enroll.enroll(s4, c2);
		Enroll.enroll(s2, c3);
		Enroll.enroll(s2, c3); // Since duplicate so isn't added to list, displays "Student already enrolled!"
		Enroll.display();

		System.out.println("");
		Enroll.drop(s1, c1);
		Enroll.drop(s1, c1); //Since already course dropped, so displays "Student not enrolled!"
		Enroll.drop(s1, c2);
		Enroll.drop(s3, c1);
		Enroll.display();
	}

}
