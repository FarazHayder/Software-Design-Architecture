import java.util.ArrayList;

public class OnlineOrder implements Order{

	ArrayList<Product> products = new ArrayList<Product>();
	ArrayList<Integer> quantities = new ArrayList<Integer>();
	int total = 0;

	public void addProduct(Product product, int quantity) {
		products.add(product);
		quantities.add(quantity);
		System.out.println("Product added successfully!");
	}
	public void removeProduct(Product product, int quantity) {
		if(products.contains(product)) {
			int index = products.indexOf(product);
			products.remove(index);
			quantities.remove(index);
		}
		else {
			System.out.println("Product not found!");
		}
	}
	public void calculateTotal() {
		total = 0;
		for(int i=0; i<products.size(); i++) {
			total += products.get(i).getPrice() * quantities.get(i);
		}
		System.out.println("Total Price: " + total);
	}
}
