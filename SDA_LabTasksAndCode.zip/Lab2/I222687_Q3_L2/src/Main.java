
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Electronics laptop = new Electronics("HP Victus", 750, "Best Laptop");
		Electronics laptop1 = new Electronics("HP Omen", 1000, "Amazing Laptop");
		Electronics mobilePhone = new Electronics("Iphone 15", 1000, "Amazing Mobile Phone");
		Clothing shirt = new Clothing("T-shirt", 20, "Cool T-shirt");
		Clothing shirt1 = new Clothing("Turtle Neck", 30, "Cool Turtle Neck");
		Clothing pants = new Clothing("Ripped Jeans", 25, "Ripped Denim Jeans with style");
		Books storybook = new Books("Harry Potter", 80, "A fantasy reading book about magic.");
		Books novel = new Books("Forty Rules of Love", 50, "A fictional book loosely based on the life of Maulana Rumi and Shams of Tabriz.");

		OnlineOrder order1 = new OnlineOrder();
		order1.addProduct(laptop, 2);
		order1.addProduct(laptop1, 1);
		order1.addProduct(novel, 1);
		OnlineOrder order2 = new OnlineOrder();
		order2.addProduct(mobilePhone, 2);
		order2.addProduct(shirt, 3);
		order2.addProduct(pants, 1);
		OnlineOrder order3 = new OnlineOrder();
		order3.addProduct(shirt1, 5);
		order3.addProduct(pants, 2);
		order3.addProduct(storybook, 5);

		System.out.println();
		Customer c1 = new Customer();
		c1.placeOrder(order1);
		c1.placeOrder(order2);
		c1.viewOrderHistory();
		System.out.println();
		Customer c2 = new Customer();
		c2.placeOrder(order3);
		c2.placeOrder(order2);
		c2.viewOrderHistory();
	
	}

}
