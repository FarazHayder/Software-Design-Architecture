
interface Product {
	
	String getName(); // Returns the name of the product.
	float getPrice(); // Returns the price of the product.
	String getDescription(); // Returns the description of the product.

}
