import java.util.ArrayList;

public class Customer {

	String name;
	String email;
	String address;
	ArrayList<OnlineOrder> orders = new ArrayList<OnlineOrder>();
	
	void placeOrder(OnlineOrder order) {
		orders.add(order);
	}
	void viewOrderHistory() {
		for(OnlineOrder order: orders) {
			for(Product product: order.products) {				
				System.out.println(product.getName() + " | " + product.getPrice() + " | " + product.getDescription());
			}
			order.calculateTotal();
			System.out.println();
		}
	}
}
