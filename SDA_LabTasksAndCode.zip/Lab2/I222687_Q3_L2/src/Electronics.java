
public class Electronics implements Product {

	String name;
	float price;
	String description;

	Electronics(String name, float price, String description){
		this.name = name;
		this.price = price;
		this.description = description;
	}
	
	public String getName() {
		return name;
	}
	public float getPrice() {
		return price;
	}
	public String getDescription() {
		return description;
	}
	
}
