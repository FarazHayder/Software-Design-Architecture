import java.util.Scanner;

class Professors extends Person{
	
	Scanner input = new Scanner(System.in);
	int count = 0;
	
	
	void addCourse() {
		if (count>4) {
			System.out.println("Cannot add more than 5 courses.");
			return;
		}
		System.out.print("Enter course: ");
		String course = input.nextLine();
		courses.add(course);
		count++;
	}
	void removeCourse(int index) {
		if (count<=0) {
			System.out.println("No courses to remove.");
			return;
		}
		if (index>count) {
			System.out.println("No course placed at this index.");
			return;
		}
		courses.remove(index);
		System.out.println("Course removed successfully!");
		count--;
	}
	
}
