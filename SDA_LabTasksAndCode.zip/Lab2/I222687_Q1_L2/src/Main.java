
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s1 = new Student();
		s1.addCourse();
		s1.addCourse();
		s1.addCourse();
		s1.addCourse();
		s1.addCourse();
		s1.display();
		
		Professors p1 = new Professors();
		p1.addCourse();
		p1.addCourse();
		p1.addCourse();
		p1.addCourse();
		p1.addCourse();
		p1.addCourse();
		p1.removeCourse(6);
		p1.removeCourse(0);
		p1.removeCourse(0);
		p1.removeCourse(0);
		p1.removeCourse(0);
		p1.removeCourse(0);
		p1.removeCourse(0);
	}

}
