import java.util.Scanner;

class Student extends Person{

	Scanner input = new Scanner(System.in);
	
	int count = 0;
	float[] grades = new float[30];
	
	void addCourse() {
		if (count>29) {
			System.out.println("Cannot add more than 30 courses.");
			return;
		}
		System.out.print("Enter course: ");
		String course = input.nextLine();
		courses.add(course);
		System.out.print("Enter grade: ");
		grades[count] = input.nextInt();
		input.nextLine(); // For input buffer
		count++;
	}
	void display() {
		for (int i=0; i<count; i++) {
			System.out.println(courses.get(i));
		}
		float avgGrade = 0;
		for (int i=0; i<count; i++) {
			avgGrade += grades[i];
		}
		avgGrade /= count;
		System.out.println("\nAverage Grade: " + avgGrade);
	}
	
}
