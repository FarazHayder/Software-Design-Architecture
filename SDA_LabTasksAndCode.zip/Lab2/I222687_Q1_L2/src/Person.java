import java.util.LinkedList;

public abstract class Person {
	String name;
	String address;
	LinkedList<String> courses = new LinkedList<String>();
	
	abstract void addCourse();
}
