import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in); //let's say part of syntax, used for input
		
		
		// Practice 
		System.out.print("Enter value: "); //cout statement
		int num = input.nextInt();
		System.out.println(num + "\n");
		input.nextLine();
		
		System.out.println("Enter String: ");
		String str = input.nextLine();
		System.out.println(str);
		
		
		input.close();
	}

}
