import java.util.Scanner;

public class I222687_Q1F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in); //let's say part of syntax, used for input

		System.out.print("Enter size of your array: ");
		int sizeOfArr = input.nextInt();
		int[] arr = new int[sizeOfArr];
		for(int i = 0; i<sizeOfArr; i++) {
			arr[i] = input.nextInt();
		}
		int zeroes = 0, positives = 0, negatives = 0;
		for(int i = 0; i<sizeOfArr; i++) {
			if(arr[i]==0) {
				zeroes++;
			}
			else if(arr[i]>0) {
				positives++;
			}
			else if(arr[i]<0) {
				negatives++;
			}
		}
		System.out.println("\n" + "Number of Positives: " + positives);
		System.out.println("Number of Negatives: " + negatives);
		System.out.println("Number of zeroes: " + zeroes);
		
		
		input.close();
	}

}
