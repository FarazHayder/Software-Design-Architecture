
public class Account {

	int accountNumber;
	double balance;
	String accountType;
	
	public
	Account() {
		accountNumber=0;
		balance = 0;
		accountType = "Current";
	}
	Account(int accountNumber, double balance, String accountType) {
		this.accountNumber=accountNumber;
		if (balance<0) {
			this.balance = 0;
		}
		else {
			this.balance = balance;
		}
		this.accountType = accountType;
	}
	void depositMoney(double amount) {
		if (amount>0) {
			balance += amount;
		}
	}
	void withdrawMoney(double amount) {
		if (amount>0 && balance-amount>0) {
			balance -= amount;
		}
	}
	void display() {
		System.out.println("\nAccount Number: " + accountNumber);
		System.out.println("Balance: " + balance);
		System.out.println("Account Type: " + accountType);
	}
	
}
