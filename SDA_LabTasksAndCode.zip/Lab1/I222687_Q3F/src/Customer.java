import java.util.LinkedList;

public class Customer {

	int customerId;
	String name;
	LinkedList<Account> accounts;
	
	public
	Customer() {
		customerId = 0;
		name = "";
	}
	Customer(int customerId, String name, LinkedList<Account> accounts){
		this.customerId = customerId;
		this.name = name;
		this.accounts = accounts;
	}
}
