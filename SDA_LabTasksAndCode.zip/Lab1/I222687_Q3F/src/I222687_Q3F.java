import java.util.LinkedList;

public class I222687_Q3F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1 = new Account(1, 50000, "savings");
		account1.display();
		
		Account account2 = new Account(2, 25000, "current");
		account2.display();
		
		LinkedList<Account> accounts = new LinkedList<Account>();
		accounts.add(account1);
		accounts.add(account2);
		Customer customer1 = new Customer(1, "Faraz", accounts);
		
		customer1.accounts.getFirst().depositMoney(10000);
		customer1.accounts.getFirst().withdrawMoney(5000);
		customer1.accounts.getFirst().display();
	}

}
