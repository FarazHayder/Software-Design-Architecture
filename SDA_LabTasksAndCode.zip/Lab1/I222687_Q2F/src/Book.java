
public class Book {
	String title, author;
	int publicationYear;
	
	public
	Book() {
		title = "";
		author = "";
		publicationYear = 0;
	}
	Book(String title, String author, int publicationYear) {
		this.title = title;
		this.author = author;
		this.publicationYear = publicationYear;
	}
	void display(){
		System.out.println("\nTitle: " + title);
		System.out.println("Author: " + author);
		System.out.println("Publication Year: " + publicationYear);
	}
		
}
