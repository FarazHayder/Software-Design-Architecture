
public class I222687_Q2F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book1 = new Book("Book1", "Faraz", 2023);
		book1.display();
		
		Book book2 = new Book("Book2", "Hayder", 2024);
		book2.display();
		
		System.out.println("\n");
		if (book1.publicationYear==book2.publicationYear) {
			System.out.println("Both books are published in same year.");
		}
		else if (book1.publicationYear<book2.publicationYear) {
			System.out.println("Book1 is published before Book2.");
		}
		else if (book1.publicationYear>book2.publicationYear) {
			System.out.println("Book2 is published before Book1.");
		}
	}

}
